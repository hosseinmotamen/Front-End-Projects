$(document).ready(function(){
    var ullist = $('.course-section-container-sidebar-list ul > li > a').parent().children('ul');
    console.log("goh")
    ullist.hide();
      $('.course-section-container-sidebar-list li a').click(function (e) {
        e.preventDefault();
        var ullist = $(this).parent().children('ul:first');
        ullist.slideToggle();
    });
  });